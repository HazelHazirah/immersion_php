<!DOCTYPE html>
<html>
  <head>
    <title>AWS Tech Fundamentals Bootcamp</title>
    <link href="style.css" media="all" rel="stylesheet" type="text/css" />
  </head>

  <body>
    <div id="wrapper">

      <?php 

	include 'menu.php';

        include 'rds-read-data.php';

	include 'rds-initialize.php';

      ?>

    </div>
  </body>
</html>
