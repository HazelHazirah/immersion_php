<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>SG Web Hosting Immersion Day</title>
  <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
  <link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<html>
<head>
  <title>SG Web Hosting Immersion Day</title>
  <meta name="description" content="Web designer and front-end developer">
  <link href='https://fonts.googleapis.com/css?family=Raleway:100,200,400,600' rel='stylesheet' type='text/css'>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.7.4/jquery.fullPage.min.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://s3-us-west-2.amazonaws.com/parallax-theme/assets/animate.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<!-- navbar header -->
<div class="nav-header">
  <div class="nav-brand">
    <!-- img src="https://s3-us-west-2.amazonaws.com/parallax-theme/assets/bradlogo2.png"-->
  </div>
  <i class="fa fa-bars fa-3x"></i>
</div>
<!-- end navbar header -->


<!-- begin fullpage -->
<div id="fullpage">
  <!-- begin section -->
  <div class="section" style="background-image: url(aws.png); background-repeat: no-repeat; background-size: cover;" data-anchor="aboutme">

      <i id="moveDown" class="fa fa-chevron-down fa-3x bounce"></i>
  </div>

  <div class="section" data-anchor="contact">
    <div class="content wow fadeInDown" data-wow-delay="0.2s">
      <center>
        <?php include('menu.php'); ?>

        <?php include("get-index-meta-data.php"); ?>
  
        <hr />
  
        <?php include('get-cpu-load.php'); ?>
      </center>
    </div>
  </div>
 </div>
 <!-- end section -->
</div>
<!-- end fullpage -->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="https://s3-us-west-2.amazonaws.com/parallax-theme/assets/wow.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.7.4/jquery.fullPage.min.js"></script>
</body>
</html>
<!-- partial -->
  <script  src="./script.js"></script>
</body>
</html>